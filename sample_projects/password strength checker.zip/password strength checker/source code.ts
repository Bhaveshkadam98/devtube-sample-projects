<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Security Checker</title>
    <!-- Use Tailwind CSS for styling -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Font for a modern look -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #0d1117;
            color: #c9d1d9;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 1rem;
        }
        .container {
            background-color: #161b22;
            border: 1px solid #30363d;
            border-radius: 1rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            max-width: 32rem;
            width: 100%;
            padding: 2rem;
        }
        .password-meter-bar {
            height: 0.75rem;
            border-radius: 9999px;
            transition: width 0.3s ease-in-out, background-color 0.3s ease-in-out;
            background-color: #ef4444; /* red-500 */
        }
        .toggle-btn {
            position: absolute;
            right: 0.75rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            color: #9ca3af;
            transition: color 0.2s ease-in-out;
            padding: 0.25rem;
        }
        .toggle-btn:hover {
            color: #c9d1d9;
        }
    </style>
</head>
<body class="p-4">
    <div class="container">
        <h1 class="text-3xl font-bold text-center mb-6 text-blue-400">Password Strength Checker</h1>

        <div class="relative mb-6">
            <label for="password" class="block text-sm font-medium mb-2">Enter your password:</label>
            <input type="password" id="password" placeholder="••••••••" class="w-full p-3 pr-10 bg-gray-700 text-white rounded-lg placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500">
            <button id="toggle-password" class="toggle-btn" type="button">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
            </button>
        </div>

        <!-- Strength Meter -->
        <div class="mb-6">
            <div class="w-full bg-gray-700 rounded-full h-2.5">
                <div id="strength-bar" class="password-meter-bar" style="width: 0%;"></div>
            </div>
            <p id="strength-text" class="text-center mt-2 font-semibold text-sm text-gray-400">Start typing to check strength</p>
        </div>

        <!-- Feedback and suggestions -->
        <div id="feedback-card" class="card space-y-3 p-4 bg-gray-800 rounded-lg border border-gray-700">
            <h2 class="text-lg font-semibold text-gray-200">Tips for a Strong Password:</h2>
            <ul class="space-y-2">
                <li id="length-check" class="flex items-center text-sm"><span class="mr-2 text-red-500">✖</span>At least 8 characters long</li>
                <li id="uppercase-check" class="flex items-center text-sm"><span class="mr-2 text-red-500">✖</span>Include an uppercase letter</li>
                <li id="lowercase-check" class="flex items-center text-sm"><span class="mr-2 text-red-500">✖</span>Include a lowercase letter</li>
                <li id="number-check" class="flex items-center text-sm"><span class="mr-2 text-red-500">✖</span>Include a number</li>
                <li id="symbol-check" class="flex items-center text-sm"><span class="mr-2 text-red-500">✖</span>Include a symbol (e.g., !@#$%)</li>
            </ul>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const passwordInput = document.getElementById('password');
            const toggleButton = document.getElementById('toggle-password');
            const strengthBar = document.getElementById('strength-bar');
            const strengthText = document.getElementById('strength-text');
            
            const checks = {
                length: document.getElementById('length-check'),
                uppercase: document.getElementById('uppercase-check'),
                lowercase: document.getElementById('lowercase-check'),
                number: document.getElementById('number-check'),
                symbol: document.getElementById('symbol-check')
            };

            const criteria = {
                length: { min: 8, points: 25 },
                uppercase: { regex: /[A-Z]/, points: 25 },
                lowercase: { regex: /[a-z]/, points: 15 },
                number: { regex: /[0-9]/, points: 15 },
                symbol: { regex: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>/?`~]/, points: 20 }
            };

            const updateFeedback = (check, isValid) => {
                const iconSpan = check.querySelector('span');
                if (isValid) {
                    iconSpan.textContent = '✓';
                    iconSpan.className = 'mr-2 text-green-500';
                } else {
                    iconSpan.textContent = '✖';
                    iconSpan.className = 'mr-2 text-red-500';
                }
            };

            const updateStrengthDisplay = (score) => {
                let text = '';
                let color = '';

                if (score === 0) {
                    text = 'Start typing to check strength';
                    color = '#6b7280';
                } else if (score < 50) {
                    text = 'Weak';
                    color = '#ef4444'; // red
                } else if (score < 75) {
                    text = 'Fair';
                    color = '#f59e0b'; // amber
                } else if (score < 100) {
                    text = 'Good';
                    color = '#3b82f6'; // blue
                } else {
                    text = 'Strong!';
                    color = '#10b981'; // green
                }
                
                strengthText.textContent = text;
                strengthText.style.color = color;
                strengthBar.style.width = `${score}%`;
                strengthBar.style.backgroundColor = color;
            };

            passwordInput.addEventListener('input', () => {
                const password = passwordInput.value;
                let score = 0;

                // Length check
                const isLengthValid = password.length >= criteria.length.min;
                if (isLengthValid) {
                    score += criteria.length.points;
                }
                updateFeedback(checks.length, isLengthValid);

                // Uppercase check
                const hasUppercase = criteria.uppercase.regex.test(password);
                if (hasUppercase) {
                    score += criteria.uppercase.points;
                }
                updateFeedback(checks.uppercase, hasUppercase);

                // Lowercase check
                const hasLowercase = criteria.lowercase.regex.test(password);
                if (hasLowercase) {
                    score += criteria.lowercase.points;
                }
                updateFeedback(checks.lowercase, hasLowercase);

                // Number check
                const hasNumber = criteria.number.regex.test(password);
                if (hasNumber) {
                    score += criteria.number.points;
                }
                updateFeedback(checks.number, hasNumber);

                // Symbol check
                const hasSymbol = criteria.symbol.regex.test(password);
                if (hasSymbol) {
                    score += criteria.symbol.points;
                }
                updateFeedback(checks.symbol, hasSymbol);

                updateStrengthDisplay(score);
            });
            
            toggleButton.addEventListener('click', () => {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);

                // Toggle the SVG icon
                toggleButton.innerHTML = type === 'password' ? 
                    `<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>` : 
                    `<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.25l-4.5-4.5m-2.25 2.25l-2.25 2.25m9-9l4.5 4.5m2.25-2.25l2.25-2.25M12 21a9 9 0 110-18 9 9 0 010 18z" />
                        <path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>`;
            });
        });
    </script>
</body>
</html>
